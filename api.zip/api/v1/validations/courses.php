<?php

class CoursesValidation{

    public function validate($obj){
        //receive data

        if (!isset($obj->name) || empty($obj->name)){
            return 'One of more fields are missing-1';

        } else if (!isset($obj->duration) || empty($obj->duration)){
            return 'One of more fields are missing-2';

        } else if (!isset($obj->course_type) || empty($obj->course_type)){
            return 'One of more fields are missing-3';

        }  else if (!isset($obj->cover_image) || empty($obj->cover_image)){
            return 'One of more fields are missing-4';

        }  else if (!isset($obj->overview) || empty($obj->overview)){
            return 'One of more fields are missing-5';

        }  else if (!isset($obj->category_id) || empty($obj->category_id )){
            return 'One of more fields are missing-6';

        }  else{
            return '';
            
        }
    }

}