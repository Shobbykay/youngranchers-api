<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');
require __DIR__ . "/inc/bootstrap.php";

//Controllers
require PROJECT_ROOT_PATH . "/controller/api/UserController.php";
require PROJECT_ROOT_PATH . "/controller/api/SubscriptionController.php";
require PROJECT_ROOT_PATH . "/controller/api/CoursesController.php";
require PROJECT_ROOT_PATH . "/controller/api/TopicsController.php";


$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri = explode( '/', $uri );

// print_r( $uri );

$resources = [
    "user",
    "lessons",
    "courses",
    "subscriptions"
];

$actions = [
    "create",
    "list",
    "view",
    "update",
    "delete"
];


if ((isset($uri[2]) && !in_array($uri[5], $resources) ) || !isset($uri[3])) {

    header("HTTP/1.1 404 Not Found");
    $response = [
        "status" => "error",
        "message" => "Resource not found, refer to API doc"
    ];
    echo json_encode($response);
    exit();

}



//ROUTING
if ($uri[5] == 'user'){
    //user route

    $objFeedController = new UserController();
    $strMethodName = $uri[3] . 'Action';
    $objFeedController->{$strMethodName}();


} else if ($uri[5] == 'subscriptions'){

    array_push($actions, "add_user");

    if ((isset($uri[6]) && !in_array($uri[6], $actions)) || (isset($uri[7]))){
        header("HTTP/1.1 404 Not Found");
        $response = [
            "status" => "error",
            "message" => "Resource not found, refer to API doc"
        ];
        echo json_encode($response);
        exit();
    }

    $objFeedController = new SubscriptionController();
    $strMethodName = $uri[6];
    $objFeedController->{$strMethodName}();

    // $response = [
    //     "status" => "error".$uri[5],
    //     "message" => "Welcome to subscriptions"
    // ];
    // echo json_encode($response);

}  else if ($uri[5] == 'courses'){

    array_push($actions, "user");

    if ((isset($uri[6]) && !in_array($uri[6], $actions)) || ($uri[6] == 'user' || $uri[6] == 'view')){

        if (!isset($uri[7]) || empty($uri[7])){
            header("HTTP/1.1 404 Not Found");
            $response = [
                "status" => "error",
                "message" => "Resource not found, refer to API doc"
            ];
            echo json_encode($response);
            exit();
        }

        $objFeedController = new CoursesController();
        $strMethodName = "user_courses";

        if ($uri[6] == 'view'){
            $strMethodName = "view_course";
        }

        $objFeedController->{$strMethodName}($uri[7]);
        exit();

    } else if ($uri[6] !== 'user'){
        if ((isset($uri[6]) && !in_array($uri[6], $actions)) || (isset($uri[7]))){
            header("HTTP/1.1 404 Not Found");
            $response = [
                "status" => "error",
                "message" => "Resource not found, refer to API doc"
            ];
            echo json_encode($response);
            exit();
        }
    }

    
    $objFeedController = new CoursesController();
    $strMethodName = $uri[6];
    $objFeedController->{$strMethodName}();

}

