<?php

require_once PROJECT_ROOT_PATH . "/model/database.php";

class CoursesModel extends Database{

    public function insertCourses($data){

        $name = $data->name;
        $duration = $data->duration;
        $course_type = addslashes($data->course_type);
        $cover_image = addslashes(urlencode($data->cover_image));
        $overview = addslashes($data->overview);
        $category_id = $data->category_id;
        $created_by = 'developer';
        $date = Date('Y-m-d h:i:s');
        
        return $this->insert("INSERT INTO courses(name, category_id, duration, course_type, cover_image, overview, created_by, created_date) VALUES ('$name', '$category_id', '$duration', '$course_type', '$cover_image', '$overview', '$created_by', '$date')");

    }

    public function checkCourse($name){
        return $this->count("SELECT COUNT(1) count FROM courses WHERE name='$name'");
    }

    public function checkCourseCategory($id){
        return $this->count("SELECT COUNT(1) count FROM category WHERE id='$id'");
    }

    public function listCourses(){
        return $this->list("SELECT a.id, a.name, a.category_id, b.name category_name, a.duration, a.course_type, a.cover_image, a.overview, 0 enrolled_users, a.created_by, a.created_date FROM `courses` a
        LEFT JOIN category b ON a.category_id=b.id
        ORDER BY a.name DESC");
    }

    public function listSingleCourse($course_id){
        return $this->list("SELECT a.id, a.name, a.category_id, b.name category_name, a.duration, a.course_type, a.cover_image, a.overview, 0 enrolled_users, a.created_by, a.created_date FROM `courses` a
        LEFT JOIN category b ON a.category_id=b.id
        WHERE a.id='$course_id'
        ORDER BY a.name DESC");
    }

    public function listUserCourses($user_id){
        return $this->list("SELECT a.id, a.name, a.category_id, b.name category_name, a.duration, a.course_type, a.cover_image, a.overview, a.created_by, a.created_date FROM `courses` a
        LEFT JOIN category b ON a.category_id=b.id
        WHERE a.id IN (SELECT course_id FROM user_courses WHERE user_id='".$user_id."')
        ORDER BY a.name DESC");
    }

}
